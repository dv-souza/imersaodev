var listaFilmes = [
  "https://br.web.img2.acsta.net/pictures/19/07/23/20/57/4907896.jpg",
  "https://i.ytimg.com/vi/WwW1nqV3pI0/movieposter_en.jpg",
  "https://br.web.img3.acsta.net/medias/nmedia/18/91/90/98/20169244.jpg"
];

for (var indice = 0; indice < listaFilmes.length; indice++) {
  document.write("<img src=" + listaFilmes[indice] + ">");
}
